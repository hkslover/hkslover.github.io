﻿#include <ntddk.h>
	
VOID DriverUnload(PDRIVER_OBJECT driver)
{

	DbgPrint("Goodbye Snow");
}
 

NTSTATUS DriverEntry(PDRIVER_OBJECT driver, PUNICODE_STRING reg_path)
{
	
	DbgPrint("HELLO Snow");
        DbgPrint("%wZ",reg_path);
	
	driver->DriverUnload = DriverUnload;
	return STATUS_SUCCESS;
}

